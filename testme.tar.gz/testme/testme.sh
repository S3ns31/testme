#!/bin/bash
#
#
# test to reboot system with sysctl 
# 

# author : phoogeen
# nickname : x0xr00t
# build : 29122019
#
# toolname : -

author="P.Hoogeveen"
version="v.1.1"
read -p "Enter your username: " user
echo ""
echo ""
echo "          build by $author | version $version" 
echo ""
echo ""
echo ""

# Ask user for pw sudo
sudo -s <<EOF
expect "password for username:"
send -- "user-password\r"
expect eof

exec /home/$user/testme/core/test

